#ifndef __SERVICES_H__
#define __SERVICES_H__
int GetPid(void);
void Sleep(int);
#endif
