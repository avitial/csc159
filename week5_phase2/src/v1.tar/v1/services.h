// services.h, 159

#ifndef __SERVICES_H__
#define __SERVICES_H__
int GetPid(void);
//int Sleep(int, int);
void Sleep(int);
#endif
