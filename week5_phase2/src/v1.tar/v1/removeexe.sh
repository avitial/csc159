#!/bin/bash

# remove files so env is clean for spede-mkmf execution
rm GDB159.RC
rm Makefile
rm Makefilee
rm make.orig
rm GidOS.dli
rm *.o
